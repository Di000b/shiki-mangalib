// background.js — "фоновый" скрипт расширения.
// Почему запросы делаем здесь, а не в content.js?
// Content-скрипт живёт на странице shikimori.io, и браузер блокирует его запросы
// к другим сайтам (политика CORS). А у фонового скрипта есть права из
// "host_permissions" в manifest.json — ему можно ходить на api.cdnlibs.org.

const API = "https://api.cdnlibs.org/api";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "api") return; // чужие сообщения игнорируем

  fetch(API + msg.path, { headers: { "Site-Id": "1" } }) // 1 = mangalib
    .then((res) => {
      if (!res.ok) throw new Error("Ошибка сервера: " + res.status);
      return res.json();
    })
    .then((json) => sendResponse({ ok: true, data: json.data }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  return true; // ВАЖНО: говорит браузеру "ответ придёт позже, асинхронно"
});
