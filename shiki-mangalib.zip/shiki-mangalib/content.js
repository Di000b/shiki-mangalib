// content.js — скрипт, который работает на страницах Шикимори.

// ---------- 1. Утилиты ----------

function api(path) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "api", path }, (res) => {
      if (!res) return reject(new Error("Нет ответа от расширения"));
      res.ok ? resolve(res.data) : reject(new Error(res.error));
    });
  });
}

const store = {
  async get(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  },
  set(key, value) {
    return chrome.storage.local.set({ [key]: value });
  },
};

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function getTitles() {
  const h1 = document.querySelector("h1");
  if (!h1) return [];
  return h1.textContent.split("/").map((s) => s.trim()).filter(Boolean);
}

const chId = (ch) => `${ch.volume}-${ch.number}`;
const chLabel = (ch) => `Том ${ch.volume}, глава ${ch.number}` + (ch.name ? ` — ${ch.name}` : "");
const readerUrl = (slug, ch) => `https://mangalib.me/ru/${slug}/read/v${ch.volume}/c${ch.number}`;

// Ключ текущей страницы Шикимори, например "/mangas/115503".
// Это ФУНКЦИЯ, а не константа: при переходах без перезагрузки адрес меняется.
const getPageId = () => location.pathname.split("-")[0];

// Другие сайты, где можно поискать мангу.
// ВНИМАНИЕ: адреса поиска — предположения, их нужно проверить на самих сайтах.
const SOURCES = [
  {
    id: "remanga",
    name: "Remanga",
    host: "remanga.org",
    search: (q) => `https://remanga.org/search?query=${encodeURIComponent(q)}`,
  },
  {
    id: "comx",
    name: "Com-X",
    host: "com-x.life",
    // Com-X сделан на движке DLE, у него стандартный адрес поиска
    search: (q) => `https://com-x.life/index.php?do=search&subaction=search&story=${encodeURIComponent(q)}`,
  },
];

// Режимы открытия: "tab" — вкладка, "panel" — окошко расширения, "full" — весь экран
const MODES = [
  { id: "tab", label: "Новая вкладка" },
  { id: "panel", label: "В окошке" },
  { id: "full", label: "На весь экран" },
];
let mode = "tab";

async function loadMode() {
  const saved = await store.get("mode");
  if (saved) return saved;
  return (await store.get("inline")) === true ? "full" : "tab";
}

// Для чужих сайтов включаем sandbox ("песочницу") у iframe: сайт остаётся рабочим
// (скрипты, формы, свои cookie), но не может увести всю страницу Шикимори на другой адрес —
// так часто пытаются "защититься от показа во фрейме".
const EXTERNAL_SANDBOX =
  "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-presentation allow-downloads";

const emptyState = () => ({ manga: null, chapters: [], last: null, bookmarks: [] });
let state = emptyState();

// Ссылки, которые пользователь привязал к этой манге: { remanga: "https://...", comx: "https://..." }
let extLinks = {};
let sitesOpen = false; // раскрыт ли блок "Другие сайты" (помним между перерисовками)

async function loadExtLinks() {
  extLinks = (await store.get("ext:" + getPageId())) || {};
}
function saveExtLinks() {
  return store.set("ext:" + getPageId(), extLinks);
}

// ---------- 2. Каркас интерфейса ----------
// Элементы создаём сразу, но в страницу добавляем в sync() (см. раздел 7).

const panel = el("aside", "sml-panel");
panel.hidden = true;

const header = el("div", "sml-header");
const title = el("h2", "sml-title", "Читать мангу");
const closeBtn = el("button", "sml-close", "×");
closeBtn.setAttribute("aria-label", "Закрыть");
closeBtn.addEventListener("click", () => {
  panel.hidden = true;
  updateFab();
});
header.append(title, closeBtn);

const body = el("div", "sml-body");
const resizer = el("div", "sml-resizer");
panel.append(resizer, header, body);

const fab = el("button", "sml-fab", "Читать мангу");
fab.hidden = true;
fab.addEventListener("click", () => {
  panel.hidden = !panel.hidden;
  if (!panel.hidden && !body.children.length) init();
  updateFab();
});

// Показывать ли плавающую кнопку: только на странице манги и не во время чтения
let onMangaPage = false;
function updateFab() {
  const reading = Boolean(activeReader) && (activeReader.kind === "full" || !panel.hidden);
  fab.hidden = !onMangaPage || reading;
}

function showMessage(text) {
  body.replaceChildren(el("p", "sml-message", text));
}

// Ссылка на внешний сайт. Открывается так же, как главы: по режиму.
function externalLink(text, url) {
  const link = el("a", "sml-chapter", text);
  link.href = url;
  link.target = "_blank";
  link.rel = "noopener";
  link.addEventListener("click", (e) => {
    const withModifier = e.ctrlKey || e.metaKey || e.shiftKey;
    if (mode !== "tab" && !withModifier) {
      e.preventDefault();
      openUrl(url, text, mode);
    }
  });
  return link;
}

// Спросить у пользователя ссылку и запомнить её для этой манги
async function bindLink(src, rerender) {
  const input = prompt(
    `Вставьте ссылку на мангу или на нужную главу на ${src.name} (адрес из браузера):`,
    extLinks[src.id] || ""
  );
  if (!input) return;

  let url;
  try {
    url = new URL(input.trim());
  } catch {
    alert("Это не похоже на ссылку.");
    return;
  }
  const hostOk = url.hostname === src.host || url.hostname.endsWith("." + src.host);
  if (url.protocol !== "https:" || !hostOk) {
    alert(`Ссылка должна вести на ${src.host}.`);
    return;
  }
  extLinks[src.id] = url.href;
  await saveExtLinks();
  rerender();
}

// Раскрывающийся блок "Другие сайты"
function otherSites(open, rerender) {
  const query = getTitles()[0] || "";
  const details = el("details", "sml-more");
  details.open = open || sitesOpen;
  details.addEventListener("toggle", () => (sitesOpen = details.open));
  details.append(el("summary", "", "Другие сайты"));

  for (const src of SOURCES) {
    const saved = extLinks[src.id];
    if (saved) {
      // Ссылка уже привязана: открыть, заменить или удалить
      const row = el("div", "sml-row");
      const edit = el("button", "sml-star", "✎");
      edit.title = "Заменить ссылку";
      edit.setAttribute("aria-label", `Заменить ссылку на ${src.name}`);
      edit.addEventListener("click", () => bindLink(src, rerender));

      const del = el("button", "sml-star", "×");
      del.title = "Убрать ссылку";
      del.setAttribute("aria-label", `Убрать ссылку на ${src.name}`);
      del.addEventListener("click", async () => {
        delete extLinks[src.id];
        await saveExtLinks();
        rerender();
      });

      row.append(externalLink(`Открыть на ${src.name}`, saved), edit, del);
      details.append(row);
    } else {
      const bind = el("button", "sml-chapter sml-linkbtn", `Привязать ссылку на ${src.name}`);
      bind.addEventListener("click", () => bindLink(src, rerender));
      details.append(bind);
    }
    details.append(externalLink(`Искать на ${src.name}`, src.search(query)));
  }
  return details;
}

// ---- Ручной поиск на MangaLib ----

// Адрес поиска по каталогу — предположение, его нужно проверить на сайте
const mangalibSearchUrl = (q) => `https://mangalib.me/ru/catalog?q=${encodeURIComponent(q)}`;

// Пользователь вставляет ссылку на мангу (или на любую главу) — достаём из неё
// адрес вида "176491--baki-rahen" и дальше работаем как при обычном поиске.
async function bindMangaLib() {
  const input = prompt("Вставьте ссылку на мангу на MangaLib (страницу манги или любую главу):", "");
  if (!input) return;

  let url;
  try {
    url = new URL(input.trim());
  } catch {
    alert("Это не похоже на ссылку.");
    return;
  }
  const hostOk = url.hostname === "mangalib.me" || url.hostname.endsWith(".mangalib.me");
  // У MangaLib адрес манги начинается с цифр и двух дефисов: 176491--baki-rahen
  const slug = url.pathname.split("/").find((part) => /^\d+--/.test(part));
  if (!hostOk || !slug) {
    alert("Не удалось найти мангу в ссылке. Нужна ссылка вида mangalib.me/ru/manga/176491--baki-rahen");
    return;
  }
  const name = getTitles()[0] || slug;
  loadChapters({ slug_url: slug, name, rus_name: name });
}

// Поиск по API с названием, которое введёт пользователь
async function searchCustom() {
  const q = prompt("Введите название для поиска на MangaLib:", getTitles()[0] || "");
  if (q && q.trim()) searchNames([q.trim()]);
}

// Три ручных варианта. collapsed = true — спрятать в раскрывающийся блок.
function manualMangaLib(collapsed) {
  const wrap = collapsed ? el("details", "sml-more") : el("div", "sml-manual");
  if (collapsed) wrap.append(el("summary", "", "Это не та манга? Найти на MangaLib вручную"));

  const bind = el("button", "sml-chapter sml-linkbtn", "Привязать ссылку на MangaLib");
  bind.addEventListener("click", bindMangaLib);

  const custom = el("button", "sml-chapter sml-linkbtn", "Найти на MangaLib по другому названию");
  custom.addEventListener("click", searchCustom);

  wrap.append(bind, custom, externalLink("Искать на MangaLib (сайт)", mangalibSearchUrl(getTitles()[0] || "")));
  return wrap;
}

function showError(text) {
  body.replaceChildren(
    el("p", "sml-message", text),
    modeSwitcher(() => showError(text)),
    manualMangaLib(false),
    otherSites(true, () => showError(text))
  );
}

function renderNotFound() {
  body.replaceChildren(
    el("p", "sml-message", "На MangaLib такой манги не нашлось. Попробуйте другие сайты:"),
    modeSwitcher(renderNotFound),
    manualMangaLib(false),
    otherSites(true, renderNotFound)
  );
}

// ---------- 3. Растягивание панели влево ----------

const MIN_WIDTH = 320;
const DEFAULT_WIDTH = 380;

function setPanelWidth(w) {
  w = Math.max(MIN_WIDTH, Math.min(w, window.innerWidth));
  panel.style.setProperty("--sml-w", w + "px");
  return w;
}

store.get("width").then((w) => {
  if (w) setPanelWidth(w);
});

resizer.setAttribute("role", "separator");
resizer.setAttribute("aria-orientation", "vertical");
resizer.setAttribute("aria-label", "Изменить ширину панели");
resizer.tabIndex = 0;
resizer.title = "Потяните, чтобы изменить ширину (двойной клик — сбросить)";

resizer.addEventListener("pointerdown", (e) => {
  resizer.setPointerCapture(e.pointerId);
  panel.classList.add("sml-resizing");
  document.body.style.userSelect = "none";
});
resizer.addEventListener("pointermove", (e) => {
  if (!resizer.hasPointerCapture(e.pointerId)) return;
  setPanelWidth(window.innerWidth - e.clientX);
});
function stopResizing(e) {
  if (!resizer.hasPointerCapture(e.pointerId)) return;
  resizer.releasePointerCapture(e.pointerId);
  panel.classList.remove("sml-resizing");
  document.body.style.userSelect = "";
  store.set("width", Math.round(panel.getBoundingClientRect().width));
}
resizer.addEventListener("pointerup", stopResizing);
resizer.addEventListener("pointercancel", stopResizing);
resizer.addEventListener("keydown", (e) => {
  if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
  e.preventDefault();
  const step = e.key === "ArrowLeft" ? 20 : -20;
  const w = setPanelWidth(panel.getBoundingClientRect().width + step);
  store.set("width", Math.round(w));
});
resizer.addEventListener("dblclick", () => {
  store.set("width", setPanelWidth(DEFAULT_WIDTH));
});

// ---------- 4. Запуск и поиск манги ----------

async function init() {
  mode = await loadMode();
  await loadExtLinks();
  const saved = await store.get("manga:" + getPageId());
  if (saved) return loadChapters(saved);
  search();
}

async function searchNames(names) {
  const pid = getPageId(); // запомнили страницу: вдруг пользователь уйдёт, пока идёт поиск
  mode = await loadMode();
  await loadExtLinks();
  showMessage("Ищу мангу на MangaLib…");
  try {
    for (const name of names) {
      const results = await api("/manga?q=" + encodeURIComponent(name));
      if (pid !== getPageId()) return;
      if (results.length) return renderResults(results);
    }
    renderNotFound();
  } catch (err) {
    if (pid === getPageId()) showError("Не получилось загрузить данные: " + err.message);
  }
}

// Обычный поиск — по названиям со страницы Шикимори
function search() {
  return searchNames(getTitles());
}

function renderResults(results) {
  const list = el("ul", "sml-list");
  for (const item of results.slice(0, 8)) {
    const li = el("li");
    const btn = el("button", "sml-item");
    btn.append(
      el("span", "sml-item-name", item.rus_name || item.name),
      el("span", "sml-item-sub", item.name)
    );
    btn.addEventListener("click", () => loadChapters(item));
    li.append(btn);
    list.append(li);
  }
  body.replaceChildren(
    el("p", "sml-hint", "Выберите подходящую мангу:"),
    list,
    manualMangaLib(true),
    otherSites(false, () => renderResults(results))
  );
}

// ---------- 5. Главы, последняя глава и закладки ----------

async function loadChapters(manga) {
  const pid = getPageId();
  showMessage("Загружаю главы…");
  try {
    const { slug_url, name, rus_name } = manga;
    await store.set("manga:" + pid, { slug_url, name, rus_name });

    mode = await loadMode();
    await loadExtLinks();
    const chapters = await api(`/manga/${slug_url}/chapters`);
    if (pid !== getPageId()) return;
    if (!chapters.length) return showMessage("Глав пока нет.");

    state = {
      manga: { slug_url, name, rus_name },
      chapters,
      last: (await store.get("last:" + slug_url)) || null,
      bookmarks: (await store.get("bm:" + slug_url)) || [],
    };
    renderChapters(true);
  } catch (err) {
    if (pid === getPageId()) showError("Не получилось загрузить главы: " + err.message);
  }
}

function markLast(ch) {
  state.last = chId(ch);
  store.set("last:" + state.manga.slug_url, state.last);
  setTimeout(() => renderChapters(), 50);
}

function chapterLink(ch, extraClass, text) {
  const link = el("a", "sml-chapter " + extraClass, text || chLabel(ch));
  link.href = readerUrl(state.manga.slug_url, ch);
  link.target = "_blank";
  link.rel = "noopener";

  link.addEventListener("click", (e) => {
    const withModifier = e.ctrlKey || e.metaKey || e.shiftKey;
    if (mode !== "tab" && !withModifier) {
      e.preventDefault();
      openReader(ch, mode);
    }
    markLast(ch);
  });
  link.addEventListener("auxclick", () => markLast(ch));
  return link;
}

function chapterRow(ch) {
  const isCurrent = chId(ch) === state.last;
  const isMarked = state.bookmarks.includes(chId(ch));

  const row = el("li", "sml-row");
  const link = chapterLink(ch, isCurrent ? "sml-current" : "");

  const star = el("button", "sml-star", isMarked ? "★" : "☆");
  star.setAttribute("aria-pressed", String(isMarked));
  star.setAttribute("aria-label", isMarked ? "Убрать закладку" : "Добавить в закладки");
  if (isMarked) star.classList.add("sml-star-on");
  star.addEventListener("click", () => toggleBookmark(ch));

  row.append(link, star);
  return row;
}

async function toggleBookmark(ch) {
  const id = chId(ch);
  const i = state.bookmarks.indexOf(id);
  if (i >= 0) state.bookmarks.splice(i, 1);
  else state.bookmarks.push(id);
  await store.set("bm:" + state.manga.slug_url, state.bookmarks);
  renderChapters();
}

// Переключатель из трёх кнопок. rerender — что перерисовать после выбора.
function modeSwitcher(rerender) {
  const wrap = el("div", "sml-modes");
  wrap.append(el("span", "sml-modes-title", "Как открывать ссылки"));

  const group = el("div", "sml-segment");
  group.setAttribute("role", "radiogroup");

  for (const m of MODES) {
    const btn = el("button", "", m.label);
    btn.setAttribute("role", "radio");
    btn.setAttribute("aria-checked", String(m.id === mode));
    btn.addEventListener("click", async () => {
      mode = m.id;
      await store.set("mode", mode);
      rerender();
    });
    group.append(btn);
  }
  wrap.append(group);
  return wrap;
}

function renderChapters(scrollToCurrentChapter = false) {
  const { manga, chapters, last, bookmarks } = state;
  if (!manga) return;
  const prevScroll = body.scrollTop;

  const back = el("button", "sml-back", "← Выбрать другую мангу");
  back.addEventListener("click", search);

  const page = el("a", "sml-chapter", "Открыть страницу манги на MangaLib");
  page.href = `https://mangalib.me/ru/manga/${manga.slug_url}`;
  page.target = "_blank";
  page.rel = "noopener";

  const parts = [
    back,
    el("p", "sml-hint", manga.rus_name || manga.name),
    page,
    modeSwitcher(() => renderChapters()),
    otherSites(false, () => renderChapters()),
  ];

  const lastCh = chapters.find((c) => chId(c) === last);
  if (lastCh) {
    parts.push(chapterLink(lastCh, "sml-continue", "Продолжить: " + chLabel(lastCh)));
  }

  const marked = chapters.filter((c) => bookmarks.includes(chId(c)));
  if (marked.length) {
    const markedList = el("ul", "sml-list");
    marked.forEach((ch) => markedList.append(chapterRow(ch)));
    parts.push(el("p", "sml-hint", "Закладки"), markedList);
  }

  const allList = el("ul", "sml-list sml-all");
  chapters.forEach((ch) => allList.append(chapterRow(ch)));
  parts.push(el("p", "sml-hint", "Все главы"), allList);

  body.replaceChildren(...parts);

  if (scrollToCurrentChapter) scrollToCurrent();
  else body.scrollTop = prevScroll;
}

function scrollToCurrent() {
  const current = body.querySelector(".sml-all .sml-current");
  if (current) current.scrollIntoView({ block: "center" });
}

// ---------- 6. Читалка: в окошке панели или на весь экран ----------

const readers = {};
let activeReader = null;

function makeReader(kind) {
  const r = { kind, index: 0, custom: null };
  r.root = el("div", `sml-reader sml-reader-${kind}`);
  r.root.hidden = true;

  const bar = el("div", "sml-reader-bar");
  const mk = (text, label, handler) => {
    const b = el("button", "sml-reader-btn", text);
    b.title = label;
    b.setAttribute("aria-label", label);
    b.addEventListener("click", handler);
    return b;
  };

  const back = mk("← Назад", "Вернуться к списку", () => {
    closeReader();
    scrollToCurrent();
  });
  r.prev = mk("‹", "Предыдущая глава", () => stepReader(r, -1));
  r.next = mk("›", "Следующая глава", () => stepReader(r, 1));

  const toPanel = kind === "full";
  const swap = mk(
    toPanel ? "⤡" : "⤢",
    toPanel ? "Свернуть в окошко" : "Открыть на весь экран",
    () => {
      const other = toPanel ? "panel" : "full";
      if (r.custom) openUrl(r.custom.url, r.custom.label, other);
      else openReader(state.chapters[r.index], other);
    }
  );

  r.ext = el("a", "sml-reader-btn", "↗");
  r.ext.title = "Открыть в новой вкладке";
  r.ext.setAttribute("aria-label", "Открыть в новой вкладке");
  r.ext.target = "_blank";
  r.ext.rel = "noopener";

  r.label = el("span", "sml-reader-title");
  bar.append(back, r.prev, r.next, swap, r.ext, r.label);

  r.frame = document.createElement("iframe");
  r.frame.className = "sml-reader-frame";
  r.frame.allow = "fullscreen";

  // Подсказка показывается только для внешних сайтов (см. showReaderChapter)
  r.note = el("span", "sml-reader-note", "Если страница пустая или с ошибкой — сайт не разрешает показ в окне. Откройте её кнопкой ↗ в новой вкладке.");
  r.note.hidden = true;

  r.root.append(bar, r.note, r.frame);
  (kind === "panel" ? panel : document.body).append(r.root);
  return r;
}

// Показать читалку нужного вида (общая часть для глав и для внешних страниц)
function presentReader(kind) {
  closeReader();
  if (!readers[kind]) readers[kind] = makeReader(kind);
  const r = readers[kind];
  activeReader = r;
  return r;
}

function revealReader(r) {
  r.root.hidden = false;
  if (r.kind === "panel") {
    panel.hidden = false;
    body.hidden = true;
  } else {
    document.documentElement.style.overflow = "hidden";
  }
  updateFab();
}

// Открыть главу MangaLib
function openReader(ch, kind) {
  const r = presentReader(kind);
  r.custom = null;
  r.index = state.chapters.indexOf(ch);
  showReaderChapter(r);
  revealReader(r);
}

// Открыть произвольную страницу (поиск на Remanga, Com-X и т. п.)
function openUrl(url, label, kind) {
  const r = presentReader(kind);
  r.custom = { url, label };
  showReaderChapter(r);
  revealReader(r);
}

function showReaderChapter(r) {
  if (r.custom) {
    r.label.textContent = r.custom.label;
    r.note.hidden = false;
    r.frame.setAttribute("sandbox", EXTERNAL_SANDBOX); // ставим ДО src
    r.frame.src = r.custom.url;
    r.ext.href = r.custom.url;
    r.prev.disabled = true;
    r.next.disabled = true;
    return;
  }
  const ch = state.chapters[r.index];
  const url = readerUrl(state.manga.slug_url, ch);
  r.label.textContent = chLabel(ch);
  r.note.hidden = true;
  r.frame.removeAttribute("sandbox"); // MangaLib работает без песочницы
  r.frame.src = url;
  r.ext.href = url;
  r.prev.disabled = r.index <= 0;
  r.next.disabled = r.index >= state.chapters.length - 1;
}

function stepReader(r, delta) {
  const i = r.index + delta;
  if (i < 0 || i >= state.chapters.length) return;
  r.index = i;
  showReaderChapter(r);
  markLast(state.chapters[i]);
}

function closeReader() {
  if (!activeReader) return;
  activeReader.root.hidden = true;
  activeReader.frame.src = "about:blank";
  activeReader = null;
  document.documentElement.style.overflow = "";
  body.hidden = false;
  updateFab();
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && activeReader) {
    closeReader();
    scrollToCurrent();
  }
});

// ---------- 7. Переходы между страницами Шикимори ----------
// Шикимори — "одностраничный" сайт (Turbolinks): при переходе по ссылкам он НЕ
// перезагружает страницу, а подменяет содержимое. Поэтому расширение не может
// делать всё один раз при загрузке. Функция sync() вызывается при каждой смене
// страницы и приводит наш интерфейс в порядок.

const isMangaPage = () => /^\/(mangas|ranobe)\//.test(location.pathname);
let currentPageId = null;

function sync() {
  if (!isMangaPage()) {
    // Ушли со страницы манги: прячем всё
    if (onMangaPage) {
      onMangaPage = false;
      closeReader();
      panel.hidden = true;
      currentPageId = null;
      updateFab();
    }
    return;
  }

  // Turbolinks заменяет <body> целиком, и наши элементы пропадают.
  // isConnected = "элемент сейчас находится в документе".
  const nodes = [panel, fab, readers.full && readers.full.root].filter(Boolean);
  for (const node of nodes) {
    if (!node.isConnected) document.body.append(node);
  }

  onMangaPage = true;

  // Перешли на другую мангу: сбрасываем состояние панели
  const id = getPageId();
  if (id !== currentPageId) {
    currentPageId = id;
    closeReader();
    panel.hidden = true;
    body.replaceChildren();
    state = emptyState();
    extLinks = {};
  }
  updateFab();
}

// События Turbolinks (в разных версиях называются по-разному)
["turbolinks:load", "page:load", "page:change"].forEach((name) => document.addEventListener(name, sync));
window.addEventListener("popstate", sync); // кнопки "назад/вперёд"
setInterval(sync, 700);                    // страховка, если события не сработали
sync();
